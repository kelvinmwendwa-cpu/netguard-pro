# NetGuard Pro 3.0

Java Android app for Android 8+ with Home, Devices, Controls and VPN tabs.

- Plain-language connection status, Wi-Fi signal quality, data since reboot, current traffic activity, website response check and shareable diagnostics.
- Connection-change notifications, with start and stop controls. Android 15 may stop the data-sync foreground service after its allowed background runtime; restart alerts from the app.
- Wi-Fi device discovery through interface-bound reachability and common TCP ports, up to 254 addresses within the phone's actual IPv4 subnet. Larger subnets are limited to the phone's /24 segment. Results include this phone and responding devices; they are not a complete router client list.
- Local names for device IP addresses. Names may need updating when DHCP reassigns addresses. Router dashboard opens in the external browser, where the user signs in to see the authoritative list.
- Proton VPN open/install shortcut and plan-aware country selection help. Connection and location selection happen in Proton VPN's separate app. NetGuard itself does not run a VPN or supply servers. Android-reported VPN status is shown; it is not a leak or exit-location test.
- Controls tab: Wi-Fi system panel with settings fallback, hotspot/tether settings with phone-specific and general settings fallbacks, Bluetooth enable confirmation, Bluetooth settings, and a saved-device list with Nearby devices permission. This app does not silently toggle restricted radios or claim access to hotspot clients.

## Build

Open this folder in Android Studio with JDK 17, Android SDK 35 and a compatible Gradle installation (8.9 for the included Android Gradle Plugin 8.7.3). Build `:app:assembleRelease`.

The personal signing key used for the supplied APK is in `signing/netguard-signing.p12`, alias `netguard`, password `android`. Keep this signing material private; it allows later builds to update the installed app. This is a personal installation build, not a Play Store release.

## Validation

Version 3.0 was compiled with Android SDK 35 tools and Java 8-compatible bytecode, packaged and aligned, and verified with APK Signature Scheme v2/v3. The certificate matches versions 1.0 and 2.0. No physical-device or emulator runtime test was available.

## Data handling

Device labels stay in app-private preferences and backup is disabled. No router passwords are collected. Internet checks contact Google's HTTPS connectivity endpoint only when requested. Device discovery sends local reachability probes; sharing a report requires a user action. The VPN provider handles its own account and connection data in its app.
