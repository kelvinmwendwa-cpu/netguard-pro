package com.netguard.pro;
import android.app.*;
import android.content.*;
import android.net.*;
import android.os.*;
public class MonitorService extends Service {
 public static volatile boolean running=false;
 Handler h=new Handler(Looper.getMainLooper());ConnectivityManager cm;boolean last=false;boolean initialized=false;
 Runnable tick=new Runnable(){public void run(){Network n=cm.getActiveNetwork();NetworkCapabilities c=n==null?null:cm.getNetworkCapabilities(n);boolean online=c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);if(initialized&&online!=last)notifyState(online);last=online;initialized=true;h.postDelayed(this,30000);}};
 @Override public void onCreate(){super.onCreate();cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NotificationManager m=getSystemService(NotificationManager.class);m.createNotificationChannel(new NotificationChannel("monitor","Network monitoring",NotificationManager.IMPORTANCE_LOW));m.createNotificationChannel(new NotificationChannel("alerts","Network alerts",NotificationManager.IMPORTANCE_DEFAULT));Notification n=new Notification.Builder(this,"monitor").setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("NetGuard Pro monitoring").setContentText("Checking internet connection every 30 seconds").setOngoing(true).setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE)).build();startForeground(101,n);running=true;h.post(tick);}
 void notifyState(boolean online){Notification n=new Notification.Builder(this,"alerts").setSmallIcon(android.R.drawable.stat_notify_error).setContentTitle(online?"Internet restored":"Internet disconnected").setContentText("NetGuard Pro detected a connection change").setAutoCancel(true).build();getSystemService(NotificationManager.class).notify(102,n);}
 @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
 @Override public void onTimeout(int startId,int fgsType){stopSelf();}
 @Override public void onDestroy(){running=false;h.removeCallbacks(tick);super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
